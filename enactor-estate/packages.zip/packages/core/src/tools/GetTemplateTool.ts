import { LocalTool, ToolContext } from "./LocalTool";
import { ToolDefinition } from "../ModelClient";
import { TemplateResolver } from "../TemplateResolver";

export class GetTemplateTool implements LocalTool {
  constructor(private templateResolver: TemplateResolver) {}

  getDefinition(): ToolDefinition {
    return {
      type: "function",
      function: {
        name: "get_template",
        description:
          "Fetches the raw XML template for a specific entity type so it can be filled out with actual values.",
        parameters: {
          type: "object",
          properties: {
            entityName: {
              type: "string",
              description:
                "The exact name of the entity type (e.g. 'device', 'pos-terminal').",
            },
          },
          required: ["entityName"],
        },
      },
    };
  }

  async execute(
    args: Record<string, unknown>,
    _context: ToolContext,
  ): Promise<string> {
    const entityName = args.entityName as string;
    if (!entityName) return "Error: entityName argument is required.";

    try {
      const templateContent = await this.templateResolver.resolve(entityName);
      return templateContent;
    } catch (error) {
      return `Failed to fetch template: ${(error as Error).message}`;
    }
  }
}
